if (WebExtension === undefined) {
  var WebExtension = chrome || browser;
}

var ExtensionStorage = (datamodel, datamodel_updates)  => {
  'use strict';
  let self = {},
    options = {},
    locked = false,
    save_que = false,
    init = false,
    version = 0,
    filters = [],
    dm = datamodel,
    dmu = datamodel_updates,
    upgrade = (items) => {
      for (let i = items.version + 1, n = dmu.length; i < n; ++i) {
        dmu[i](items);
        version = i;
      }
      return items;
    },
    load = () => {
      return new Promise((resolve) => {
        WebExtension.storage.sync.get(dm, (items) => {
          upgrade(items);
          options = items.options;
          version = items.version;
          resolve();
        });
      });
    },
    save = () => {
      return new Promise((resolve) => {
        if (locked) {
          save_que = true;
          return;
        }

        locked = true;
        WebExtension.storage.sync.set({options: options, version: version}, async () => {
          locked = false;
          if (save_que) {
            save_que = false;
            await save();
          }
          resolve();
        });
      });
    };

    WebExtension.storage.onChanged.addListener((changes, namespace) => {
      'use strict';
      if (changes && changes.options && namespace === 'sync') {
        WebExtension.runtime.sendMessage({action: 'current_options', data: {options: changes.options.newValue}});
      }
    });
  self = {
    init: async (callback) => {
      if (!init) {
        await load();
        init = true;
      }
      if (callback) {
        callback();
      }
    },
    addValidationFilter: (filter) => {
      filters.push(filter);
    },
    update: (o) => {
      for (let i = 0, n = filters.length; i < n; ++i) {
        if (!filters[i](o)) {
          return false;
        }
      }
      options = o;
      return save();
    },
    options: () => {
      return options;
    },
    reset: async () => {
      let items = JSON.parse(JSON.stringify(dm));
      options = upgrade(items).options;
      return await save();
    }
  };
  return self;
};
