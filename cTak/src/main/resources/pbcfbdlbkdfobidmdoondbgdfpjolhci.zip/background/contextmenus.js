if (WebExtension === undefined) {
  var WebExtension = chrome || browser;
}
var contextMenu = (id, title, options) => {
  'use strict';
  var self = {},
    o = options || o,
    contexts = o.contexts || ['all'],
    enabled = o.enabled === false ? false : o.enabled || true,
    clicked = (info, tab) => {
      if (info.menuItemId === id) {
        (o.clicked || (() => {}))(info, tab);
      }
    };

  WebExtension.contextMenus.create({
    id: id,
    title: title,
    contexts: contexts,
    enabled: enabled
  });

  WebExtension.contextMenus.onClicked.addListener(clicked);
  self = {
    enable: (enable) => {
      if (enabled === enable)
        return;
      self.update({enabled: enable});
      enabled = enable;
    },
    update: (updateProperties) => {
      return WebExtension.contextMenus.update(
        id,
        updateProperties
      );
    },
    remove: () => {
      return WebExtension.contextMenus.remove(id);
    },
    refresh: () => {
      return WebExtension.contextMenus.refresh();
    },
  };
  return self;
  };
